#undef LOG_TAG
#define LOG_TAG "CalcClient"

#include <binder/IBinder.h>
#include <binder/IServiceManager.h>
#include <binder/Parcel.h>
#include <utils/Log.h>
#include <utils/RefBase.h>
using namespace android;

int main() {
    sp<IServiceManager> sm = defaultServiceManager();
    sp<IBinder> binder = sm->getService(String16("CalcService"));
    if (binder == 0) {
        LOGW("CalcService has not been published yet...");
        return 0;
    }

    Parcel data;  // Input
    Parcel reply;  // Output
    data.writeInt32(100);
    data.writeInt32(50);
    binder->transact(0, data, &reply);  // Add function
    LOGI("CalcService returns: %d", reply.readInt32());
}

