#undef LOG_TAG
#define LOG_TAG "CalcService"

#include "CalcService.h"
#include <binder/IPCThreadState.h>
#include <binder/IServiceManager.h>
#include <binder/ProcessState.h>
#include <utils/Log.h>
#include <utils/RefBase.h>
using namespace android;

int main() {
    sp<ProcessState> proc(ProcessState::self());
    sp<IServiceManager> sm = defaultServiceManager();

    LOGI("Add CalcService to ServiceManager");
    sm->addService(String16("CalcService"), new CalcService());
    ProcessState::self()->startThreadPool();
    IPCThreadState::self()->joinThreadPool();
}

