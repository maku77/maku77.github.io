#include "CalcService.h"

#include <binder/Parcel.h>

status_t CalcService::onTransact(uint32_t code, const Parcel& data,
        Parcel* reply, uint32_t flags) {
    switch (code) {
    case 0:  // Add function
        {
            int a = data.readInt32();
            int b = data.readInt32();
            reply->writeInt32(a + b);
        }
        break;
    case 1:  // Subtract function
        {
            int a = data.readInt32();
            int b = data.readInt32();
            reply->writeInt32(a - b);
        }
        break;
    default:
        return BBinder::onTransact(code, data, reply, flags);
    }
    return NO_ERROR;
}

