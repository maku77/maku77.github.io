#include "CalcService.h"

#include <binder/Parcel.h>

enum {
    CODE_ADD = IBinder::FIRST_CALL_TRANSACTION,
    CODE_SUBTRACT,
};

status_t CalcService::onTransact(uint32_t code, const Parcel& data,
        Parcel* reply, uint32_t flags) {
    switch (code) {
    case CODE_ADD:  // Add function
        {
            int a = data.readInt32();
            int b = data.readInt32();
            reply->writeInt32(a + b);
        }
        break;
    case CODE_SUBTRACT:  // Subtract function
        {
            int a = data.readInt32();
            int b = data.readInt32();
            reply->writeInt32(a - b);
        }
        break;
    default:
        return BBinder::onTransact(code, data, reply, flags);
    }
    return NO_ERROR;
}

