#ifndef CALC_SERVICE_H
#define CALC_SERVICE_H

#include <binder/Binder.h>
using namespace android;

class CalcService : public BBinder {
public:
    virtual status_t onTransact(uint32_t code, const Parcel& data, Parcel* reply, uint32_t flags);
    virtual ~CalcService() {}
};

#endif // CALC_SERVICE_H
