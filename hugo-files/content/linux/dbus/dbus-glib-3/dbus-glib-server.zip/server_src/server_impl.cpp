#include "server_impl.h"

// Remote object implementation.
G_DEFINE_TYPE(RemoteObject, remote_obj, G_TYPE_OBJECT);

static void remote_obj_init(RemoteObject *obj) {
}

static void remote_obj_class_init(RemoteObjectClass *klass) {
}

// Methods and signals implementation.
void ServerImpl_add(RemoteObject *obj,
        gint val1, gint val2, gint* ret_val, GError *err) {
    *ret_val = val1 + val2;
}

void ServerImpl_subtract(RemoteObject *obj,
        gint val1, gint val2, gint* ret_val, GError *err) {
    *ret_val = val1 - val2;
}

