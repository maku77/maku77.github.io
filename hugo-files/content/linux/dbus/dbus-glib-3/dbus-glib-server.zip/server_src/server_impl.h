#ifndef SERVER_IMPL_H
#define SERVER_IMPL_H

#include <dbus/dbus-glib.h>

// Defined by G_DEFINE_TYPE()
GType remote_obj_get_type();

struct RemoteObject {
    GObject parent_instance;

    // instance members
    int dummy1;
    int dummy2;
};

struct RemoteObjectClass {
    GObjectClass parent_class;

    // class members
    int dummy1;
    int dummy2;
};

void ServerImpl_add(RemoteObject *obj,
        gint val1, gint val2, gint* ret_val, GError *err);

void ServerImpl_subtract(RemoteObject *obj,
        gint val1, gint val2, gint* ret_val, GError *err);

#endif // SERVER_IMPL_H
