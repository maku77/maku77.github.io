#include <cstdlib>
#include <dbus/dbus-glib.h>
#include <iostream>
using namespace std;

#include "server_impl.h"
#include "server_autogen.h"

const char *SERVICE_BUS_NAME = "com.example.MyApp";
const char *SERVICE_OBJECT_PATH = "/com/example/MyApp";

static void showErrorAndExit(const char* msg) {
    cerr << "Error: " << msg << endl;
    exit(1);
}

static void initDbus() {
    g_type_init();
    if (!g_thread_supported()) {
        g_thread_init(NULL);
    }
    dbus_g_thread_init();
}

static gpointer registerService() {
    // Connect to a session bus.
    DBusGConnection *con = dbus_g_bus_get(DBUS_BUS_SESSION, NULL);
    if (con == NULL) {
        showErrorAndExit("Failed to connect to session bus");
    }

    DBusGProxy *busProxy = dbus_g_proxy_new_for_name(con,
            DBUS_SERVICE_DBUS,     // "org.freedesktop.DBus"
            DBUS_PATH_DBUS,        // "/org/freedesktop/DBus"
            DBUS_INTERFACE_DBUS);  // "org.freedesktop.DBus"
    if (busProxy == NULL) {
        showErrorAndExit("Failed to get a proxy for D-Bus");
    }

    // Register service name (bus name)
    GError *err = NULL;
    guint result;
    gboolean ret = dbus_g_proxy_call(busProxy, "RequestName", &err,
            G_TYPE_STRING, SERVICE_BUS_NAME,
            G_TYPE_UINT, 0,
            G_TYPE_INVALID,
            G_TYPE_UINT, &result,
            G_TYPE_INVALID);
    if (!ret || result != 1) {
        showErrorAndExit("Failed to register a service name to D-Bus");
    }

    GType t = remote_obj_get_type();
    GObject *obj = (GObject*) g_object_new(t, NULL);

    // Install introspection information (register methods and signals).
    dbus_g_object_type_install_info(t, &dbus_glib_ServerImpl_object_info);

    // Export a remote object.
    dbus_g_connection_register_g_object(con, SERVICE_OBJECT_PATH, obj);

    return obj;
}

int main() {
    initDbus();
    GMainLoop *loop = g_main_loop_new(NULL, false);
    registerService();
    g_main_loop_run(loop);
}
