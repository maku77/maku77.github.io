#!/bin/bash
clang++ -o server server.cpp server_impl.cpp `pkg-config --cflags --libs dbus-glib-1`
