#undef LOG_TAG
#define LOG_TAG "CalcClient"

#include "ICalcService.h"
#include <binder/IBinder.h>
#include <binder/IInterface.h>  // interface_cast
#include <binder/IServiceManager.h>
#include <binder/Parcel.h>
#include <utils/Log.h>
#include <utils/StrongPointer.h>  // sp
using namespace android;

int main() {
    sp<IServiceManager> sm = defaultServiceManager();
    sp<IBinder> binder = sm->getService(String16("CalcService"));
    if (binder == 0) {
        LOGW("CalcService has not been published yet...");
        return 0;
    }
    sp<ICalcService> calc = interface_cast<ICalcService>(binder);

    int result = calc->subtract(100, 50);  // Subtract function
    LOGI("CalcService returns: %d", result);
}

