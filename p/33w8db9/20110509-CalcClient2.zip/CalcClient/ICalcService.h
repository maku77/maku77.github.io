#ifndef I_CALC_SERVICE_H
#define I_CALC_SERVICE_H

#include <binder/IInterface.h>  // IInterface, BpInterface
#include <utils/StrongPointer.h>  // sp

class ICalcService : public android::IInterface {
public:
    DECLARE_META_INTERFACE(CalcService);
    virtual int add(int a, int b) = 0;
    virtual int subtract(int a, int b) = 0;
};

class BpCalcService : public android::BpInterface<ICalcService> {
public:
    BpCalcService(const android::sp<android::IBinder>& obj);
    ~BpCalcService();
    virtual int add(int a, int b);
    virtual int subtract(int a, int b);
};

#endif // I_CALC_SERVICE_H
