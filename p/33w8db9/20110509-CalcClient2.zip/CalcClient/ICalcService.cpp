#include "ICalcService.h"
#include <binder/IBinder.h>
#include <binder/Parcel.h>
using namespace android;

// Implementation of ICalcService.
IMPLEMENT_META_INTERFACE(CalcService, "sample.CalcService");

BpCalcService::BpCalcService(const sp<IBinder>& obj) : BpInterface<ICalcService>(obj) {
}

BpCalcService::~BpCalcService() {
}

enum {
    CODE_ADD = IBinder::FIRST_CALL_TRANSACTION,
    CODE_SUBTRACT,
};

int BpCalcService::add(int a, int b) {
    Parcel data;  // input
    Parcel reply;  // output
    data.writeInt32(a);
    data.writeInt32(b);
    remote()->transact(CODE_ADD, data, &reply);  // Add function of CalcService
    return reply.readInt32();
}

int BpCalcService::subtract(int a, int b) {
    Parcel data;  // input
    Parcel reply;  // output
    data.writeInt32(a);
    data.writeInt32(b);
    remote()->transact(CODE_SUBTRACT, data, &reply);  // Subtract function of CalcService
    return reply.readInt32();
}

