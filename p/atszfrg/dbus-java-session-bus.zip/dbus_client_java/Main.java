import org.freedesktop.dbus.DBusConnection;
import org.freedesktop.dbus.exceptions.DBusException;
import com.example.MyApp.Calc;

public class Main {
    public static void main(String[] args) {
        DBusConnection conn = null;
        Calc calc = null;

        try {
            conn = DBusConnection.getConnection(DBusConnection.SESSION);
            calc = (Calc) conn.getRemoteObject(
                    "com.example.MyApp",  // Bus name
                    "/com/example/MyApp",  // Object path
                    Calc.class);  // Interface
        } catch (DBusException ex) {
            System.err.println("Failed to obtain a remote object.");
            System.err.println(ex.getMessage());
            System.exit(1);
        }

        try {
            int a = calc.Add(100, 200);
            int b = calc.Subtract(100, 200);
            System.out.println(a);
            System.out.println(b);
        } catch (RuntimeException ex) {
            System.err.println("Failed to invoke a remote method.");
            System.err.println(ex.getMessage());
        }

        conn.disconnect();
    }
}
