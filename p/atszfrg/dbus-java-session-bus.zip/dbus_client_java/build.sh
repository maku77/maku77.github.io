#!/bin/bash
javac -cp libdbus-java-full-2.7.jar Main.java com/example/MyApp/Calc.java

