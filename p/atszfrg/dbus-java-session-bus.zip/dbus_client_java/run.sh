#!/bin/sh
java -cp ./libdbus-java-full-2.7.jar:. -Djava.library.path=. Main
