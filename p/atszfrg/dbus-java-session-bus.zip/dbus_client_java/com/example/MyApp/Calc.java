/* File: com/example/MyApp/Calc.java */
package com.example.MyApp;
import org.freedesktop.dbus.DBusInterface;
public interface Calc extends DBusInterface
{

  public int Add(int val1, int val2);
  public int Subtract(int val1, int val2);

}
